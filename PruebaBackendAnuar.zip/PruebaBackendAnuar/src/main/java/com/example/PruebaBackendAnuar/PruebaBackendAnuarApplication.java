package com.example.PruebaBackendAnuar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebaBackendAnuarApplication {

	public static void main(String[] args) {
		SpringApplication.run(PruebaBackendAnuarApplication.class, args);
	}

}
